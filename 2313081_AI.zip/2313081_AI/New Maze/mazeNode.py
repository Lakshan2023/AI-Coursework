import random


# The Class Node stores the information of each cell in the maze.
class Node:
    def __init__(self, x, y, nodeType=None, cellNumber=None):
        # (x, y) coordinates of the cell
        self.coordinates = (x, y)
        # Type of the cell (Start, Goal, Barrier, Blocked, Visited)
        self.nodeType = nodeType
        # Cell number of the cell
        self.cellNumber = cellNumber
        # Parent node of the cell
        self.parentNode = None
        # Heuristic cost of the cell
        self.heuristicCost = 0
        # Total cost of the cell
        self.totalCost = 0


class Maze:
    # Class Maze generate a random maze with a start, goal and barrier positions.
    def __init__(self):
        self.mazeNodes = [[Node(x, y, cellNumber=y + x * 6) for x in range(6)] for y in range(6)]
        self.startPosition = None
        self.goalPosition = None
        self.generateRandomMaze()

        for node in self.mazeNodes:
            for val in node:
                print(f"{val.cellNumber}  - {val.nodeType}".ljust(20), end=" ")
            print("")

    # Generate a random node of a given type in the maze.
    def generateRandomNode(self, startNode, endNode, nodeType):
        # Randomly generate a cell number within startNode and endNode number.
        cellNumber = random.randint(startNode, endNode)

        # Convert the cell number to (x, y) coordinates.
        xPosition = cellNumber // 6
        yPosition = cellNumber % 6

        # Assigning the node type to the randomly selected cell
        self.mazeNodes[yPosition][xPosition].nodeType = nodeType

        # Assigning the cell number to the randomly selected cell through node class
        self.mazeNodes[yPosition][xPosition].cellNumber = cellNumber

        # Assigning the start and goal positions to the maze
        if nodeType == "Start":
            # Assign start position x and y coordinates to the maze
            self.startPosition = (xPosition, yPosition)
        elif nodeType == "Goal":
            # Assign goal position x and y coordinates to the maze
            self.goalPosition = (xPosition, yPosition)

    # Generate a random maze with a start, goal and barrier positions.
    def generateRandomMaze(self):
        # Generate the start node
        self.generateRandomNode(0, 11, "Start")
        # Generate the goal node
        self.generateRandomNode(24, 35, "Goal")

        # Generate 4 barrier nodes
        for count in range(4):
            while True:
                # Generate a random cell number within 0 and 35
                cellNumber = random.randint(0, 35)
                # get the x position of the cell
                xPosition = cellNumber // 6
                # Get the Y position of the cell
                yPosition = cellNumber % 6
                # Check if the cell is not a start, goal or barrier node
                if self.mazeNodes[yPosition][xPosition].nodeType is None:
                    # Assign the node type "Barrier" to the cell
                    self.mazeNodes[yPosition][xPosition].nodeType = "Barrier"
                    # Assign the cell number to the cell
                    self.mazeNodes[yPosition][xPosition].cellNumber = cellNumber
                    break
