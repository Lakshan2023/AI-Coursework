class FrontierStack:
    # This class is used to build the stack for DFS search
    def __init__(self):
        # Initialize the stack
        self.mazeStack = []

    # This function adds a node to the stack
    def addNode(self, addingNode):
        self.mazeStack.append(addingNode)

    # This function checks if the stack is empty
    def isMazeStackEmpty(self):
        return len(self.mazeStack) == 0

    # This function removes a node from the stack
    def removeNode(self):
        # Check if the stack is empty
        if self.isMazeStackEmpty():
            # If the stack is empty, print the message "Empty Maze Stack"
            print("Empty Maze Stack")
        else:
            # If the stack is not empty, remove the last node from the stack
            node = self.mazeStack[-1]
            self.mazeStack = self.mazeStack[:-1]
            return node
