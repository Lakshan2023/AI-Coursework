import copy


class AstarSearchImplementor:
    # Class AstarSearchImplementor implements A* search algorithm.
    # List of visited nodes
    visited = []

    # Initial maze to get the same maze for both DFS and A* search
    initialMaze = []

    Node = None

    def __init__(self, maze):
        # Get the generated maze from the Maze class
        self.maze = maze

        # Get a copy of the dfs maze to make the initial maze
        self.initialMaze = copy.deepcopy(self.maze.mazeNodes)

        # Assign the initial maze to the modified maze (modified maze will be used for A* search)
        # It is done to get the same maze for both DFS and A* search
        self.modifiedMaze = self.getTheInitialMaze(self.initialMaze)

        # Calculate the heuristic cost for each node
        self.calculateHeuristicCost()

        # Assign the starting point and goal point
        self.startingPoint = self.modifiedMaze[self.maze.startPosition[1]][self.maze.startPosition[0]]
        self.goalPoint = self.modifiedMaze[self.maze.goalPosition[1]][self.maze.goalPosition[0]]

        # Assign the starting point as the parent node
        self.parent = self.startingPoint

        # Implement A* search
        self.aStarSearch()

        # Print the visited node list in A* search
        self.printAStarVisitedNodeLis()

        # Display the final path for A* search
        self.displayFinalPath()

        # Display the time taken to find the goal
        self.displayTimeToFindGoal()

    # This function calculates the heuristic cost for each node
    def calculateHeuristicCost(self):
        # Iterate through each node in the maze
        for index in self.modifiedMaze:
            for value in index:
                # Calculate the heuristic cost of the node |Nx - Gx| + |Ny - Gy|
                value.heuristicCost = abs(value.coordinates[0] - self.maze.goalPosition[0]) + abs(
                    value.coordinates[1] - self.maze.goalPosition[1])

    # This function implemented A * traversal
    def aStarSearch(self):
        # Assign total cost as 0
        cost = 0
        # get the starting point
        self.Node = self.startingPoint
        # Until the goal is found, traverse through the maze
        while True:
            # Check if the goal is found
            if self.goalExistsCondition(self.Node):
                return

            # Make the node as visited, if it is not the start node
            if self.Node.nodeType != "Start":
                self.Node.nodeType = "Visited"

            # Add the node to the visited list
            self.visited.append(self.Node)

            # since each edge has the same cost, add 1 to the cost
            cost += 1

            # get the neighbors of the visited node
            self.getNeighbourNodes()

    # This function gets the neighbors of the visited node
    def getNeighbourNodes(self):
        # List of achievable neighbors (Neighbors that can be visited)
        achievableNeighbours = []

        # Iterate through each visited node and get the neighbors that are not visited
        for node in self.visited:
            # Calculate the total cost of the node |Nx - Gx| + |Ny - Gy| + 1, by considering the step
            cost = node.totalCost - node.heuristicCost + 1

            # List of neighbor directions
            neighbourDirections = [(1, 0), (0, 1), (1, 1), (1, -1), (-1, 1), (-1, -1), (-1, 0), (0, -1)]

            # Iterate through each neighbor direction to find all neighbors
            for index in neighbourDirections:
                # Get the x and y coordinates of the neighbor
                newXPosition = node.coordinates[0] + index[0]
                newYPosition = node.coordinates[1] + index[1]

                # Check if the neighbor is within the maze
                if 0 <= newXPosition < 6 and 0 <= newYPosition < 6:
                    newNode = self.modifiedMaze[newYPosition][newXPosition]

                    # Check if the neighbor is not visited and not in the achievable neighbors list
                    if newNode not in self.visited and newNode not in achievableNeighbours:
                        # Check if the neighbor is not a barrier or blocked node
                        if newNode.nodeType not in ["Barrier", "Blocked"]:
                            # Calculate the total cost of the neighbour |Nx - Gx| + |Ny - Gy| + 1
                            newNode.totalCost = newNode.heuristicCost + cost
                            # Add the neighbor to the achievable neighbors list
                            achievableNeighbours.append(newNode)
                            # Assign the parent node to the neighbor
                            newNode.parentNode = node

        # If there are no achievable neighbors, print "No valid neighbors found."
        if not achievableNeighbours:
            print("No valid neighbors found.")
            return

        # Sort the achievable neighbors list
        sortedList = self.sortNeighbourList(achievableNeighbours)
        # Assign the first node in the sorted list as the next node to be visited
        self.Node = sortedList[0]

    # This function sorts the neighbor list by considering the total cost and the cell number
    def sortNeighbourList(self, ListToBeSorted):
        # Iterate through each node in the list
        for count in range(len(ListToBeSorted) - 1):
            for index in range(len(ListToBeSorted) - 1):
                # Check if the total cost of the current node is greater than the total cost of the next node
                # or if the total cost of the current node is equal to the total cost of the next node and
                # the cell number of the current node is greater than the cell number of the next node
                if ListToBeSorted[index].totalCost > ListToBeSorted[index + 1].totalCost or (
                        ListToBeSorted[index].totalCost == ListToBeSorted[index + 1].totalCost
                        and ListToBeSorted[index].coordinates[0] > ListToBeSorted[index + 1].coordinates[0]
                ):
                    # Swap the nodes
                    temp = ListToBeSorted[index]
                    ListToBeSorted[index] = ListToBeSorted[index + 1]
                    ListToBeSorted[index + 1] = temp
        # return the sorted list
        return ListToBeSorted

    # This function gets the initial maze
    def getTheInitialMaze(self, mazeNodes):
        initialMaze = []
        # Iterate through each node in the dfs maze to get the same initial maze for both DFS and A* search
        for index in mazeNodes:
            innerNodes = []
            # Make all visited, blocked and final nodes as None
            for values in index:
                if values.nodeType in ["Visited", "Blocked", "Final"]:
                    values.nodeType = None
                    values.parentNode = None
                innerNodes.append(values)
            initialMaze.append(innerNodes)
        # return the initial maze
        return initialMaze

    # This function checks if the node is the goal node
    def goalExistsCondition(self, state):
        # If the node is the goal node, return True
        if state.nodeType == "Goal":
            return True
        # Else return False
        else:
            return False

    # This function prints the visited node list in A* search
    def printAStarVisitedNodeLis(self):
        print("\n")
        print("A * Search".center(50))
        print("\nVisited node list  :  ", end="")
        for node in self.visited:
            print(node.cellNumber, end=" ")
        print(self.goalPoint.cellNumber)
        print("")

    # This function displays the final path for A* search
    def displayFinalPath(self):
        # Get the goal node
        node = self.goalPoint
        finalPath = []
        # Iterate through each node in the path
        while node is not None:
            finalPath.append(node.cellNumber)
            if node.nodeType not in ["Goal", "Start"]:
                node.nodeType = "Final"
            # get the parent of the node
            node = node.parentNode

        # Print the final path
        if finalPath:
            print("Final Path :", end=" ")
            count = 0
            for index in range(len(finalPath) - 1, -1, -1):
                print(finalPath[index], end=" ")
                count += 1
            print("")
        else:
            print("No optimal path found.")

    # This function displays the time taken to find the goal
    def displayTimeToFindGoal(self):
        spentTime = len(self.visited)
        print("\nSpent time in minutes : {}\n".format(spentTime))
