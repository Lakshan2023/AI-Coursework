from FrontierStack import FrontierStack


class DepthFirstSearchImplementor:
    # This class is used to implement the DFS search
    # visitedList is used to store the visited nodes
    visitedList = []

    def __init__(self, maze):
        # Get the generated maze from the Maze class
        self.maze = maze
        # Get the stack from the FrontierStack class
        self.Stack = FrontierStack()
        # Get the goal node
        self.GoalNode = self.maze.mazeNodes[self.maze.goalPosition[1]][self.maze.goalPosition[0]]
        # Assign the parent node as None
        self.parent = None
        # Implement DFS search
        self.DFSSearch()

    # This function implements the DFS search
    def DFSSearch(self):
        # Traverse the nodes
        self.traverseNodes()

        # Print the visited node list
        self.printDFSVisitedNodeList()

        # Display the final path
        self.displayFinalPath()

        # Calculate the time taken to find the goal
        self.displayTimeToFindGoal()

    # This function traverses the nodes
    def traverseNodes(self):
        # Get the parent node as the Starting Node
        parentNode = self.maze.mazeNodes[self.maze.startPosition[1]][self.maze.startPosition[0]]

        # Add the parent node to the stack
        self.Stack.addNode(parentNode)

        # Traverse will be done until the stack is empty or until the goal node is found
        while not self.Stack.isMazeStackEmpty():
            # Remove the last node from the stack
            popNode = self.Stack.removeNode()
            # Assign the removed node as the parent node
            popNode.parentNode = self.parent

            # Check if the goal node is found
            if self.goalStateExistCondition(popNode):
                return

            # Check if the node is not a start node to change the node type to "Visited"
            if popNode.nodeType not in ["Start"]:
                popNode.nodeType = "Visited"

            # Add the node to the visited list if it is not in the visited list
            if popNode not in self.visitedList:
                self.visitedList.append(popNode)

            # Get the neighbors of the node
            self.getNeighbourNodes(popNode.coordinates[0], popNode.coordinates[1], "Traverse")
        print("No Solution")

    # This function gets the neighbors of the node
    def getNeighbourNodes(self, X_position, Y_position, status):
        # Get the neighbor directions
        neighbourDirections = [(1, 0), (0, 1), (1, 1), (1, -1), (-1, 1), (-1, -1), (-1, 0), (0, -1)]

        # List to store the achievable neighbors
        achievableNeighbours = []

        # Iterate through each neighbor direction
        for index in neighbourDirections:
            # Get the new x and y positions
            newXPosition = X_position + index[0]
            newYPosition = Y_position + index[1]

            # Check if the new x and y positions are within the maze
            if 0 <= newXPosition < 6 and 0 <= newYPosition < 6:
                # Get the neighbor node
                neighbourNode = self.maze.mazeNodes[newYPosition][newXPosition]

                # Check if the neighbor node is not a start, barrier or blocked node and
                # if the node is not in the visited list
                if neighbourNode.nodeType not in ["Start", "Barrier",
                                                  "Blocked"] and neighbourNode not in self.visitedList:
                    achievableNeighbours.append(neighbourNode)

        # Sort the Neighbor list
        sortedNeighbourList = self.sortNeighbourNodeList(achievableNeighbours)

        # Check the status of the node ("Whether it is a traverse or backtrack")
        if status == "Traverse":
            # Check if all the neighbors are visited or if there are no neighbors to visit
            if self.checkAllNeighboursVisited(achievableNeighbours) or len(achievableNeighbours) == 0:
                # If all the neighbors are visited or if there are no neighbors to visit, backtrack the maze
                self.backtrackMaze()
            else:
                # Iterate through each neighbor in the sorted neighbor list
                for value in sortedNeighbourList:
                    # Assign the parent node to the neighbor
                    self.parent = self.visitedList[-1]
                    # Add the neighbor node to the stack
                    self.Stack.addNode(value)
        else:
            # If the status is backtracked, return the sorted neighbor list
            return sortedNeighbourList

    # This function backtracks the maze
    def backtrackMaze(self):
        # get the index of the last node in the visited list
        index = len(self.visitedList) - 1

        # Iterate through each node in the visited list
        while index >= 0:
            # Get the current node
            currentNode = self.visitedList[index]

            # Get the neighbors of the current node
            neighbors = self.getNeighbourNodes(currentNode.coordinates[0], currentNode.coordinates[1], "Backtrack")

            # Check if all the neighbors are visited or if there are no neighbors to visit
            if self.checkAllNeighboursVisited(neighbors) or len(neighbors) == 0:
                # Assign the node type as "Blocked" and assign the parent node as None
                currentNode.nodeType = "Blocked"
                currentNode.parentNode = None
                index -= 1
            else:
                self.parent = currentNode
                break

    # This function checks if all the neighbors are visited
    def checkAllNeighboursVisited(self, neighbourList):
        # Iterate through each neighbor in the neighbor list
        for value in neighbourList:
            # Check if the node type is not "Visited"
            if value.nodeType not in ["Visited"]:
                return False
        # If the length of the neighbor list is 0, return False
        if len(neighbourList) == 0:
            return False
        return True

    # This function checks if the node is the goal node
    def goalStateExistCondition(self, node):
        # If the node is the goal node, return True
        if node.nodeType == "Goal":
            return True
        # Else return False
        else:
            return False

    # This function sorts the neighbor list by considering the cell number
    def sortNeighbourNodeList(self, neighbourList):
        # Iterate through each neighbor in the neighbor list
        for index in range(0, len(neighbourList) - 1):
            for count in range(len(neighbourList) - 1):
                # Check if the cell number of the current node is greater than the cell number of the next node
                if neighbourList[count].cellNumber < neighbourList[count + 1].cellNumber:
                    temp = neighbourList[count]
                    neighbourList[count] = neighbourList[count + 1]
                    neighbourList[count + 1] = temp
        # Return the sorted neighbor list
        return neighbourList

    # This function prints the visited node list
    def printDFSVisitedNodeList(self):
        print("\n")
        print("Depth First Search".center(50))
        print("\nVisited node list  :  ", end="")
        # Iterate through each node in the visited list and print the cell number
        for node in self.visitedList:
            print(node.cellNumber, end=" ")
        print(self.GoalNode.cellNumber)
        print("")

    # This function displays the final path
    def displayFinalPath(self):
        # Assign the goal node as the node
        node = self.GoalNode
        finalPath = []

        # Iterate through each node in the visited list
        while node is not None:
            # Append the node to the final path list
            if node.parentNode is not None:
                finalPath.append(node)
            # Check if the node is the start node
            if node.nodeType == "Start":
                finalPath.append(node)
                break
            # Assign the parent node as the node
            node = node.parentNode

        # Print the final path
        print("Final Path :", end=" ")
        for index in range(len(finalPath) - 1, -1, -1):
            if finalPath[index].nodeType not in ["Start", "Goal"]:
                finalPath[index].nodeType = "Final"
            print(finalPath[index].cellNumber, end=" ")
        print("")

    # This function calculates the time taken to find the goal
    def displayTimeToFindGoal(self):
        # Get the length of the visited list (Time taken to find the goal)
        spentTime = len(self.visitedList)
        print("\nSpent time in minutes : {}\n".format(spentTime))
