from AStarSearchImplementor import AstarSearchImplementor
from DepthFirstSearchImplementor import DepthFirstSearchImplementor
from mazeNode import Maze
from DisplayMaze import DisplayMaze

# Generate the Initial maze for both DFS and A* search
generatedMaze = Maze()

# Implement DFS search
dfsSearch = DepthFirstSearchImplementor(generatedMaze)

# Implement A* search
aStarSearch = AstarSearchImplementor(generatedMaze)

# Display the maze
visualizer = DisplayMaze(generatedMaze.mazeNodes, aStarSearch.modifiedMaze)

