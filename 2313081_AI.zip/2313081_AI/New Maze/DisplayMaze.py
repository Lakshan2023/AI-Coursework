import tkinter as tk


class DisplayMaze:
    # This class is used to display the maze
    def __init__(self, dfs_maze, a_star_maze):
        self.dfs_maze = dfs_maze
        self.a_star_maze = a_star_maze
        self.visualize_mazes()

    # This function is used to visualize the maze
    def visualize_mazes(self):
        # Create the window
        window = tk.Tk()
        # Set the title of the window
        window.title("Maze Visualization")

        # Gap between the two canvases A* and DFS
        gap_width = 20

        # Creating labels for top numbering for DFS maze
        for x in range(len(self.dfs_maze[0])):
            label_text = str(x)
            tk.Label(window, text=label_text, font=('Helvetica', 12)).grid(row=0, column=x + 1, sticky='nsew')

        # Creating labels for y coordinates on the left side for DFS maze
        for y in range(len(self.dfs_maze)):
            label_text = str(y)
            tk.Label(window, text=label_text, font=('Helvetica', 12)).grid(row=y + 1, column=0, sticky='nsew')

        # Create the canvas for DFS maze
        dfs_canvas = tk.Canvas(window, width=len(self.dfs_maze[0]) * 100, height=len(self.dfs_maze) * 100)
        dfs_canvas.grid(row=1, column=1, rowspan=len(self.dfs_maze), columnspan=len(self.dfs_maze[0]), sticky='nsew')

        # Create label for DFS maze name
        tk.Label(window, text="DFS Maze", font=('Helvetica', 12)).grid(row=len(self.dfs_maze) + 2, column=1,
                                                                       columnspan=len(self.dfs_maze[0]), sticky='nsew')

        # Applying the gap between the two canvases
        window.grid_columnconfigure(len(self.dfs_maze[0]) + 1, minsize=gap_width)

        # Create labels for top numbering for A* maze
        for x in range(len(self.a_star_maze[0])):
            label_text = str(x)
            tk.Label(window, text=label_text, font=('Helvetica', 12)).grid(row=0, column=len(self.dfs_maze[0]) + 2 + x,
                                                                           sticky='nsew')

        # Create labels for y coordinates on the left side for A* maze
        for y in range(len(self.a_star_maze)):
            label_text = str(y)
            tk.Label(window, text=label_text, font=('Helvetica', 12)).grid(row=y + 1, column=len(self.dfs_maze[0]) + 1,
                                                                           sticky='nsew')

        # Create canvas for A* maze
        a_star_canvas = tk.Canvas(window, width=len(self.a_star_maze[0]) * 100, height=len(self.a_star_maze) * 100)
        a_star_canvas.grid(row=1, column=len(self.dfs_maze[0]) + 2, rowspan=len(self.a_star_maze),
                           columnspan=len(self.a_star_maze[0]), sticky='nsew')

        # Create label for A* maze name
        tk.Label(window, text="A* Maze", font=('Helvetica', 12)).grid(row=len(self.a_star_maze) + 2,
                                                                      column=len(self.dfs_maze[0]) + 2,
                                                                      columnspan=len(self.a_star_maze[0]),
                                                                      sticky='nsew')

        # Colors for both mazes
        colors = {
            'Start': 'green',
            'Goal': 'darkorange',
            'Barrier': 'black',
            'Visited': 'darkgray',
            'Blocked': 'orange',
            'Final': 'mediumpurple'
        }

        # Visualize DFS maze
        self.visualize_single_maze(dfs_canvas, self.dfs_maze, colors)

        # Visualize A* maze
        self.visualize_single_maze(a_star_canvas, self.a_star_maze, colors)

        # Start the GUI
        window.mainloop()

    # This function is used to visualize a single maze
    def visualize_single_maze(self, canvas, maze, colors):
        # Iterate through each node in the maze nodes to visualize the maze
        for y in range(len(maze)):
            for x in range(len(maze[0])):
                # Get the node type of the node
                node_type = maze[y][x].nodeType
                # Get the color of the node type
                color = colors.get(node_type, 'lightgray')

                # Create the rectangle for the node
                canvas.create_rectangle(x * 100, y * 100, (x + 1) * 100, (y + 1) * 100, fill=color, outline='black',
                                        width=1)

                # Label the node with the cell number
                label_text = f"{maze[y][x].cellNumber}"

                # Label the node with the node type
                if node_type in colors:
                    label_text += f"\n{node_type}"

                # Label the node with the parent node
                text_color = 'white' if node_type == 'Barrier' else 'black'
                canvas.create_text((x + 0.5) * 100, (y + 0.5) * 100, text=label_text, font=('Helvetica', 11),
                                   fill=text_color, justify='left', anchor='center')

                # Create the lines for the maze
                canvas.create_line(x * 100, y * 100, x * 100, (y + 1) * 100, fill='black')
                canvas.create_line(x * 100, y * 100, (x + 1) * 100, y * 100, fill='black')

        # Create the lines for the maze borders
        for x in range(len(maze[0])):
            canvas.create_line((x + 1) * 100, 0, (x + 1) * 100, len(maze) * 100, fill='black')

        # Create the lines for the maze borders
        for y in range(len(maze)):
            canvas.create_line(0, (y + 1) * 100, len(maze[0]) * 100, (y + 1) * 100, fill='black')
