import numpy as np
import skfuzzy as fuzzy
from skfuzzy import control as ctrl

# Define Input variables
data_redundancy = ctrl.Antecedent(np.arange(0, 101, 1), 'Data_Redundancy')
degradation_level = ctrl.Antecedent(np.arange(0, 10.1, 0.1), 'Degradation_Level')
error_history = ctrl.Antecedent(np.arange(0, 101, 1), 'Error_History')

# Define Output variables
likelihood_error = ctrl.Consequent(np.arange(0, 1.1, 0.1), 'Error_Likelihood')

# Fuzzify input variables (Membership function of data redundancy)
data_redundancy['Low'] = fuzzy.trapmf(data_redundancy.universe, [0, 0, 25, 40])
data_redundancy['Moderate'] = fuzzy.trimf(data_redundancy.universe, [25, 50, 75])
data_redundancy['High'] = fuzzy.trapmf(data_redundancy.universe, [65, 75, 100, 100])

# Fuzzify input variables (Membership function of degradation level)
degradation_level['Low'] = fuzzy.trapmf(degradation_level.universe, [0, 0, 2.5, 4.0])
degradation_level['Moderate'] = fuzzy.trimf(degradation_level.universe, [2.5, 5.0, 7.5])
degradation_level['High'] = fuzzy.trapmf(degradation_level.universe, [6.0, 7.5, 10.0, 10.0])

# Fuzzify input variables (Membership function of error history)
error_history['Low'] = fuzzy.gaussmf(error_history.universe, 0, 13)
error_history['Moderate'] = fuzzy.gaussmf(error_history.universe, 50, 11)
error_history['High'] = fuzzy.gaussmf(error_history.universe, 100, 13)

# Fuzzify output variables (Membership function of the error likelihood)
likelihood_error['Low'] = fuzzy.trimf(likelihood_error.universe, [0, 0.3, 0.5])
likelihood_error['Moderate'] = fuzzy.trimf(likelihood_error.universe, [0.3, 0.5, 0.7])
likelihood_error['High'] = fuzzy.trimf(likelihood_error.universe, [0.5, 0.8, 1.0])

# Error Likelihood Rules
rule1 = ctrl.Rule(error_history['High'], likelihood_error['High'])
rule2 = ctrl.Rule(data_redundancy['High'] & (degradation_level['Low']) & error_history['Low'], likelihood_error['Low'])
rule3 = ctrl.Rule(data_redundancy['High'] & (degradation_level['Low']) & error_history['Moderate'],
                  likelihood_error['Low'])
rule4 = ctrl.Rule(data_redundancy['High'] & (degradation_level['Moderate']) & (error_history['Low']),
                  likelihood_error['Low'])
rule5 = ctrl.Rule(data_redundancy['High'] & (degradation_level['Moderate']) & (error_history['Moderate']),
                  likelihood_error['Moderate'])
rule6 = ctrl.Rule(data_redundancy['High'] & (degradation_level['High']) & error_history['Moderate'],
                  likelihood_error['High'])
rule7 = ctrl.Rule(data_redundancy['High'] & (degradation_level['High']) & error_history['Low'],
                  likelihood_error['Moderate'])
rule8 = ctrl.Rule(data_redundancy['Moderate'] & (degradation_level['Moderate']) & (error_history['Moderate'] |
                                                                                   error_history['Low']),
                  likelihood_error['Moderate'])
rule9 = ctrl.Rule(data_redundancy['Moderate'] & (degradation_level['Low']) & (error_history['Low']),
                  likelihood_error['Low'])
rule10 = ctrl.Rule(data_redundancy['Moderate'] & (degradation_level['Low'] | degradation_level['High']) &
                   (error_history['Moderate']),
                   likelihood_error['Moderate'])
rule11 = ctrl.Rule(data_redundancy['Low'] & (degradation_level['Moderate']) & (error_history['Low']),
                   likelihood_error['Moderate'])
rule12 = ctrl.Rule(data_redundancy['Low'] & (degradation_level['Low']) & (error_history['Moderate'] |
                                                                          (error_history['Low'])),
                   likelihood_error['Moderate'])
rule13 = ctrl.Rule(data_redundancy['Low'] & (degradation_level['High']) & (error_history['Low'] |
                                                                           error_history['Moderate']),
                   likelihood_error['High'])

# Define the control system with rules
likelihood_error_ctrl = ctrl.ControlSystem(
    [rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9, rule10, rule11, rule12, rule13])
likelihood_errors = ctrl.ControlSystemSimulation(likelihood_error_ctrl)

# Build the User Interface to check the likelihood of errors in the system
print("Check likelihood of errors in the system \n")
while True:
    # Check data redundancy input is an integer between 0 and 100
    while True:
        try:
            data_redundancy_input = int(input("Enter Data Redundancy (0-100): "))
            if 0 <= data_redundancy_input <= 100:
                break
            else:
                print("Invalid input. Please enter an integer value between 0 and 100.")
        except ValueError:
            print("Invalid input. Please enter an integer value between 0 and 100.")

    # Check degradation level input is an integer between 0 and 10
    while True:
        try:
            degradation_level_input = float(input("Enter Degradation Level (0-10): "))
            if 0 <= degradation_level_input <= 10:
                break
            else:
                print("Invalid input. Please enter an integer value between 0 and 10.")
        except ValueError:
            print("Invalid input. Please enter an integer valid numeric value.")

    # Check error history input is an integer between 0 and 100
    while True:
        try:
            error_history_input = float(input("Enter Error History (0-100): "))
            if 0 <= error_history_input <= 100:
                break
            else:
                print("Invalid input. Please enter an integer between 0 and 100.")
        except ValueError:
            print("Invalid input. Please enter an integer valid numeric value.")

    print("\n")
    # Pass the values to the fuzzy system
    likelihood_errors.input['Data_Redundancy'] = float(data_redundancy_input)
    likelihood_errors.input['Degradation_Level'] = float(degradation_level_input)
    likelihood_errors.input['Error_History'] = float(error_history_input)
    likelihood_errors.compute()

    print("Error Likelihood Crisp Value : ", likelihood_errors.output["Error_Likelihood"])
    # Fuzzily to get a crisp value
    error_likelihood_crisp = likelihood_errors.output["Error_Likelihood"]

    # display the membership function of the error likelihood
    likelihood_error.view(sim=likelihood_errors)

    # Print the error likelihood
    if error_likelihood_crisp <= 0.4:
        print("Error Likelihood: Low\n")

        print("Suggestions for Low Error Likelihood:")
        print("- Continue normal operations.")
        print("- Monitor system performance regularly.")

    elif 0.4 < error_likelihood_crisp <= 0.6:
        print("Error Likelihood: Moderate\n")

        print("Suggestions for Moderate Error Likelihood:")
        print("- Initiate a system review to identify potential issues.")
        print("- Increase monitoring frequency.")

    else:
        print("Error Likelihood: High")

        print("Suggestions for High Error Likelihood:")
        print("- Trigger an immediate investigation and response.")
        print("- Implement corrective actions promptly.")


    print("\n\n")






